<template>
  <div id="app bg-bg-main">
    <router-view />
  </div>
</template>

<script>



export default {
  components: {
    
  },
};
</script>

<style lang="scss">

</style>
