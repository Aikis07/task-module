<template>
    <div class="tasks-list">
        <tasks-card />
    </div>
</template>

<script>
import TasksCard from '@/components/Home/TasksCard.vue';


    export default {
        components: {
            TasksCard,
        },
    }
</script>

<style lang="scss" scoped>

</style>